#include "Arete.h"
#include "Sommet.h"
#ifndef GRAPHE_H_INCLUDED
#define GRAPHE_H_INCLUDED

class Graphe
{
public:

Graphe();

void dessiner(Svgfile& a);
void dessinerKruskal(Svgfile& a);
void charger();
void Kruskal();




private:

    std::vector<Sommet*> m_sommets;
    std::vector<Arete*> m_aretes;
    std::vector<Arete*> copie_m_aretes;
    std::vector<Arete*> m_aretes_trie;
    std::vector<Graphe*> m_graphes;

//    float m_cout;

#endif // GRAPHE_H_INCLUDED
};
