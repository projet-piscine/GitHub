#include "arete.h"

Arete::Arete(std::string id, Sommet A, Sommet B, float coutA, float coutB)
        :m_id{id}, m_A{A}, m_B{B}, m_coutA{coutA} , m_coutB{coutB}

{
testK = m_id;
}

std::string Arete::getId()
{
return m_id;
}

Sommet Arete::getA()
{
    return m_A;
}

Sommet Arete::getB()
{
    return m_B;
}

 float Arete::getCout1()
{
return m_coutA;
}

 float Arete::getCout2()
{
return m_coutB;
}

void Arete::dessiner(Svgfile& a)
{
    a.addLine(m_A.getX(), m_A.getY(), m_B.getX(), m_B.getY(), Couleur(0,0,0)); //ligne
    a.addText((m_A.getX()+ m_B.getX())/2,((m_A.getY()+ m_B.getY())/2)-5,m_id,Couleur(0,0,0)); //indice arete
    a.addText(((m_A.getX()+ m_B.getX())/2)-10,((m_A.getY()+ m_B.getY())/2)+15,m_coutA,Couleur(125,125,125)); //coutA
    a.addText(((m_A.getX()+ m_B.getX())/2)+10,((m_A.getY()+ m_B.getY())/2)+15,m_coutB,Couleur(125,125,125)); //coutB
    a.addText(((m_A.getX()+ m_B.getX())/2)-15,((m_A.getY()+ m_B.getY())/2)+15,"( ",Couleur(125,125,125)); //parenthese
    a.addText(((m_A.getX()+ m_B.getX())/2),((m_A.getY()+ m_B.getY())/2)+15," ,",Couleur(125,125,125));  //virgule
    a.addText(((m_A.getX()+ m_B.getX())/2)+15,((m_A.getY()+ m_B.getY())/2)+15," )",Couleur(125,125,125)); //parenthese

}
